# quote machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/rodrigopinelli/pen/RwmGOZJ](https://codepen.io/rodrigopinelli/pen/RwmGOZJ).

